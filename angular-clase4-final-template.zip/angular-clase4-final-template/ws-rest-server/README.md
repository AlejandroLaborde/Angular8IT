# java-web-api
java web api
servicio rest
CRUD DE PRODUCTOS

get
http://localhost:8080/app-rest/api/productos

post
http://localhost:8080/app-rest/api/productos/{id}

delete
http://localhost:8080/app-rest/api/productos/{id}

put
http://localhost:8080/app-rest/api/productos/
<pre> requet:{
	"id":6,
  	"nombre": "teclado inalambrico",
  	"precio": 355  
}
</pre>

post
http://localhost:8080/app-rest/api/productos/
<pre> requet:{
	"id":7,
  	"nombre": "teclado inalambrico",
  	"precio": 355  
}
</pre>



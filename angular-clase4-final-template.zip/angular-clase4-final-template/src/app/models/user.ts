export class User {
    userName: string;
    password?: string;
    firstName: string;
    lastName: string;
    token?: string;
    curso?: any;
}

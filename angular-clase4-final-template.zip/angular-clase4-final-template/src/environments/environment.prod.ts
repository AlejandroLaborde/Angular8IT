export const environment = {
  // apiUrl: 'http://localhost:8083/app-rest',
  apiUrl: '',
  production: true
};
